import 'package:flutter/material.dart';

class MyIcons {
  static const IconData github_outline = IconData(0xe799, fontFamily: 'myIcon');
  static const IconData github = IconData(0xe7ab, fontFamily: 'myIcon');
  static const IconData fork = IconData(0xe65b, fontFamily: 'myIcon');
  static const IconData pr = IconData(0xe8b8, fontFamily: 'myIcon');
  static const IconData code = IconData(0xe646, fontFamily: 'myIcon');
}