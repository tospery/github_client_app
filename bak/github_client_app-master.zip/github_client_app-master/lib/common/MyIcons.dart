import 'package:flutter/material.dart';

/**
 * Author: xuyanpeng
 * Date: 2019/12/6 17:22
 * Description:
 */
class MyIcons {
  static const IconData fork=const IconData(
    0xe93d,
    fontFamily: 'myIcon',
    matchTextDirection: true
  );
}
